package demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try
{
	
	 // INHERITANCE BY SINGLE TABLE
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		 Session session = sessionFactory.openSession();
	     Transaction t;
	     t=session.beginTransaction();
	     FullTimeEmployee e=new FullTimeEmployee();
	     e.setEname("Phani");
	     e.setEno(108);
	     e.setSalary(20000);
	     PartTimeEmployee e1=new PartTimeEmployee();
	     e1.setEname("kumar");
	     e1.setEno(107);
	     e1.setPayment(10000);
	     session.save(e);
	     session.save(e1);

	     t.commit();
	     
	    
	/*
	
	}
	finally {}
	     
		
		
	}

}
