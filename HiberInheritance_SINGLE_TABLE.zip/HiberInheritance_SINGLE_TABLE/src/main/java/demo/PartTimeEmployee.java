package demo;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("PT")
public class PartTimeEmployee extends Employee {
	@Override
	public String toString() {
		return "PartTimeEmployee [payment=" + payment + "]";
	}

	public int getPayment() {
		return payment;
	}

	public void setPayment(int payment) {
		this.payment = payment;
	}

	private int payment;


}
